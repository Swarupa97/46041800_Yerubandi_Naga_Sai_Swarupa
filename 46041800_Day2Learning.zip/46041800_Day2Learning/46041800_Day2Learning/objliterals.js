const username = 'sanju'
const name = 'Sanjana'
const country = 'India'
const password = '123456'
const user = { 
	username,
	name, 
	country,
	password,
}
console.log(user);