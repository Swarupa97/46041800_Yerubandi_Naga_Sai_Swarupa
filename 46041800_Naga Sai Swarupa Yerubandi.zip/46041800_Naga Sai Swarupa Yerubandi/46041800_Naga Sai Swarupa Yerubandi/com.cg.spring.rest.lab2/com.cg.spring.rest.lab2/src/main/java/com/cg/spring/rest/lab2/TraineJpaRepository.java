package com.cg.spring.rest.lab2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface TraineJpaRepository extends JpaRepository<Trainee, Integer> {
}
