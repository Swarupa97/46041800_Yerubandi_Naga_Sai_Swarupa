package com.example.lab3;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MovieController {
	
	@Autowired
	MovieService movieService;
	
	@GetMapping("/Movie")
	public List<Movie> getAllMovie()
	{
		return movieService.getAllMovies();
	}
	
	@GetMapping("/Movie/{genre}")
	public List<Movie> getMovieByGenre(@PathVariable("genre") String genre)
	{
		return movieService.getMovieByGenre(genre);
	}
	
	@DeleteMapping("/Movie/{movieame}")
	public void deleteMovie(@PathVariable("movieName") String movieName)
	{
		movieService.deleteMovie(movieName);
	}
	
	@PostMapping("/Movie")
	public String insertMovie(@RequestBody Movie movie)
	{
		movieService.insertMovie(movie);
		return movie.getMovieName();
	}
	
	@PutMapping("/Movie")
	public Movie updateMovie(@RequestBody Movie movie)
	{
		return movieService.updateMovie(movie);
	}
}
