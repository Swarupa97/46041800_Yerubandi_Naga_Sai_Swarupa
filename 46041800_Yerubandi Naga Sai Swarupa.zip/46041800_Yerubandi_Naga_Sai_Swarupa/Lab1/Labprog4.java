import java.util.*;
public class Labprog4 
{
	public void Prime(int n)
	{
		int count;
		for(int j=1;j<=n;j++)
		{
			count = 0;
			for(int i=1;i<=n;i++) 
			{
				if(j % i == 0)
				{
					count++;
				}
			}
			if(count<=2)
			{
				System.out.println(j);
			}
		}
		
	} 
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Labprog4 lp = new Labprog4();
		lp.Prime(n);
		sc.close();
	}
}