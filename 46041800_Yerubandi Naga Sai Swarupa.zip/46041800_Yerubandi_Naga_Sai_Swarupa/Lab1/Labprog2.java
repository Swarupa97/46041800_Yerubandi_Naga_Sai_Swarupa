import java.util.*;
public class Labprog2 
{
	public static void main(String args[]) 
	{
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		sc.close();
		if(s.equals("red"))
		{
			System.out.println("Stop");
		}
		else if (s.equals("yellow"))
		{
			System.out.println("Ready");
		}
		else
		{
			System.out.println("Go");
		}
	}
}