package labs;

public class Lab5Prog3 {
	public static void main(String args[]) {
		Lab5Prog3 labprog3 = new Lab5Prog3();
		try {
			System.out.println(labprog3.employeeSalary(6000));
			System.out.println(labprog3.employeeSalary(2000));
		}
		catch(EmployeeException e) {
			System.out.println(e);
		}
	}
	public float employeeSalary(float salary) throws EmployeeException {
		if(salary<3000) {
			throw new EmployeeException("Salary is less than 3000");
		}
		else
			System.out.println("Salary is...");
		return salary;
	}
}