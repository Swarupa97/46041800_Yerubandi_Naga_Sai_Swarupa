package labs;

public class Lab5Prog1 {
	public static void main(String args[]) {
		Lab5Prog1 labprog1 = new Lab5Prog1();
		try {
			System.out.println(labprog1.validateAge(20));
			System.out.println(labprog1.validateAge(14));
		}
		catch(InvalidAgeException e) {
			System.out.println(e);
		}
	}
	public int validateAge(int age) throws InvalidAgeException {
		if(age<=15) {
			throw new InvalidAgeException("Age should be greater then 15");
		}
		else
			System.out.println("Age is valid");
		return age;
	}
}