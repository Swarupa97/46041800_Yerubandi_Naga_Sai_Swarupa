package labs;

public class Lab5Prog2 {
	public static void main(String args[]) {
		Lab5Prog2 labprog2 = new Lab5Prog2();
		try {
			System.out.println(labprog2.validateName("Swarupa", "Yerubandi"));
			System.out.println(labprog2.validateName(" ", " "));
		}
		catch(InvalidNameException e) {
			System.out.println(e);
		}
	}
	public String validateName(String firstName, String lastName) throws InvalidNameException {
		if(firstName == " " && lastName == " ") {
			throw new InvalidNameException("First name and last name should not be blank");
		}
		else 
			System.out.println("Name is valid");
		return "Name validation";
	}
}
