package labs;

import java.util.Arrays;

public class Lab2Demo2{
  void sortStrings(String[] a) {
	  Arrays.sort(a);
	  int s=(a.length);
	  for(int i=0;i<s;i++) {
	  for(int j=0;j<s/2;j++) {
		  System.out.println(a[j].toLowerCase());
	  }
	  for(int k=s-1;k>=s/2;k++) {
		  System.out.println(a[k].toUpperCase());
	  }
  }
  }
  public static void main(String[] args) {
	  String str[]= {"Abhi","surya","hrithik","pandu"};
	  Lab2Demo2 sorting=new Lab2Demo2();
	  sorting.sortStrings(str);
  }
}
