package oct9;

public class Book
{

    public static void main(String[] args) {
   

    }

}
